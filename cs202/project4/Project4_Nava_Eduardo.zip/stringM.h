void stringCopy(char *a, char*b);
bool stringCompare(char *a, char*b);
char stringAdd(char *a, char*b, char *r);
int stringLength(char *a);
